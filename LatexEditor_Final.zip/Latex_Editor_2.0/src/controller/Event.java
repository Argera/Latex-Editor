package controller;

public interface Event {
	
	void handle(String ...args);
	
}
