package test;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import controller.NewVersionEvent;
import controller.ReportEvent;
import controller.RollbackEvent;
import controller.VersionControllEnabled;
import model.DocumentManager;
import model.VersionStrategyFactory;
import model.VersionsManager;
import view.MainWindow;

class US7TestRollback {

	private static MainWindow window;
	private static DocumentManager doc;
	private static VersionsManager managerV;
	
	@BeforeAll
	public static void init() {
		window = new MainWindow(null);
		managerV = new VersionsManager();
		try {
			doc = new DocumentManager();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	void test() {
		ReportEvent report = new ReportEvent();
		report.handle("Report", "Author1", "Date1", "Copyright1", "Version1");
		String before = DocumentManager.getOnDisplayDocument().getContents();
		
		VersionControllEnabled enableVersion = new VersionControllEnabled();
		enableVersion.handle();
		
		
		NewVersionEvent Version = new NewVersionEvent();
		Version.handle();
		MainWindow.display(before + "Hello");
		
		RollbackEvent rollback = new RollbackEvent();
		rollback.handle();
		
		String after = DocumentManager.getOnDisplayDocument().getContents();		
		
		assertEquals(before, after);
		
	}

}
